{-# LANGUAGE ScopedTypeVariables #-}
-- | Noetig, da GHC ansonsten zu viel Speicher verbraucht.
{-# Options_GHC -fno-full-laziness #-}

-- | Ein einfacher Sudoku Loeser. Bird; Kapitel 19; "A simple Sudoku solver".
--
-- Hier gibt es zwei Loesungstrategien. Die erste ist in der Praxis nicht nutzbar.

module Sudoku where

import System.IO
import Control.DeepSeq
import Debug.Trace as T

import Puzzle
import Data.List ((\\))



-- * fuer alle Strategien

-- | Matrix definiert als Liste von Zeilen

type Matrix a = [Row a]

-- | Zeile definiert als Liste Zellen vom Typ @a@

type Row a = [a]

-- | Das Sudoku Grid, als Matrix von Buchstaben

type Grid = Matrix Digit

-- | Repraesentiere Digits via Chars (Int macht es nicht schneller)

type Digit = Char

-- | Legale Eintraege

digits :: [Char]
digits = ['1' .. '9']

-- | Eintrag ist noch "leer"

blank :: Char -> Bool
blank = (=='0')

-- | Gegeben Eingabepfad, lese 'Grid'

fromFile :: FilePath -> IO Grid
fromFile fpath =
  withFile fpath ReadMode $ \h -> do
    xss <- map (map head . words) . lines <$> hGetContents h
    return $!! xss

-- | Sehr einfache Show Funktion

showSudoku :: Grid -> IO ()
showSudoku = mapM_ putStrLn

-- * Strategie 1

-- | Zelle ist noch nicht fixiert, das hier sind die Wahlmoeglichkeiten

type Choices = [Digit]

-- | Gegeben ein initiales 'Grid', finde alle legalen Loesungen.

solveT :: Grid -> [Grid]
solveT = filter valid . expand . choices

-- | Gegeben ein grid, erstelle eine Matrix, in der jede Zelle mit den moeglichen 'Choices', also
-- einer Liste der moeglichen 'Digit's gefuellt ist.

choices :: Grid -> Matrix Choices
choices = map (map choice)

-- | Choice testet ob eine Zelle noch frei ist und gibt dann alle Kandidaten zurueck, ansonsten wird
-- der schon gesetzte Wert zurueck gegeben.

choice :: Char -> [Char]
choice d = if blank d then digits else [d]

-- | Erstelle aus der Matrix der Choices die Liste aller Kandidatengrids.

expand :: Matrix Choices -> [Grid]
expand = cartProd . map cartProd

-- | Das kartesische Produkt von @n@ Listen

cartProd :: [[a]] -> [[a]]
cartProd [] = [[]]
cartProd (xs:xss) = [x:ys | x <- xs, ys <- cartProd xss]

-- | Teste jedes Grid darauf, ob es valide ist.

valid :: Grid -> Bool
valid g = all nodups (rows g) && all nodups (cols g) && all nodups (boxs g)

-- | Testet ob in einer Liste Duplikate vorkommen, rekursiv wird fuer jedes Element getestet ob alle
-- nachfolgenden Elemente ungleich sind.

nodups :: Eq a => [a] -> Bool
nodups [] = True
nodups (x:xs) = notElem x xs && nodups xs

-- | selektiert alle Zeilen

rows :: Matrix a -> Matrix a
rows = id

-- | Selektiert alle Spalten; siehe auch 'transpose'

cols :: Matrix a -> Matrix a
cols [xs] = [[x] | x <- xs]
cols (xs:xss) = zipWith (:) xs (cols xss)

-- | Selektiert alle 3x3 Quadrate

boxs :: Matrix a -> Matrix a
boxs = map ungroup . ungroup . map cols . group . map group

-- | Neuorientierung in 3er-Gruppen: @group [1,2,3,4,5,6] == [[1,2,3],[4,5,6]]@

group :: [a] -> [[a]]
group [] = []
group xs = take 3 xs : group (drop 3 xs)

-- | Hebt eine Gruppierung auf

ungroup :: [[a]] -> [a]
ungroup = concat


-- * And now faster

-- | Entfernt illegale Auswahlen

prune :: Matrix Choices -> Matrix Choices
prune = pruneBy boxs . pruneBy cols . pruneBy rows

-- | Intern wird nur nach "rows" getestet, daher muss in Rows umgewandelt und zurueck verwandelt
-- werden.

pruneBy :: ([Row Choices] -> [Row Choices]) -> [Row Choices] -> [Row Choices]
pruneBy f = f . map pruneRow . f

pruneRow :: Row Choices -> Row Choices
-- Innerhalb einer Zeile bleiben nur die Kandidaten, die nicht in anderen Zellen dieser Reihe
-- bereits fest sind.
pruneRow row = map (remove fixed) row
  -- Die Menge [d] and singleton-belegten Zellen; also Zellen die festgelegt wurden
  where fixed = [d | [d] <- row]

-- | @xs@ sind die zu entfernenden Kandidaten, waehrend @ds@ die Kandidaten innerhalb einer Zelle
-- sind.
remove xs ds = if singleton ds then ds else ds \\ xs

-- | @((==1) . length)@

singleton :: [a] -> Bool
singleton [x] = True
singleton _ = False

-- | "prune" Lsg: generiere alle Lsg, entferne offensichtliche illegale Lsg, expandiere die
-- Restmatrix, filtere nach "validen" Matrizen

solveP :: Grid -> [Grid]
solveP = filter valid . expand . prune . choices



-- * And faster

-- | @expand1@ selektiert eine Zelle mit minimalen Auswahlmoeglichkeiten und expandiert in alle
-- Varianten.

expand1 :: Matrix Choices -> [Matrix Choices]
expand1 rows = [rows1 ++ [row1 ++ [c] : row2] ++ rows2 | c <- cs]
  where
    -- @row@ enthaelt irgendwo "n" Choices
    (rows1,row:rows2) = break (any smallest) rows
    -- @cs@ sind die erste Zelle bei der das so ist
    (row1,cs:row2) = break smallest row
    smallest cs = length cs == n
    -- Min. ueber alle rows
    n = minimum (counts rows)

-- | zaehle in die "Minima" nur die Choices, bei denen min. 2 Kandidaten vorhanden sind.

counts :: [[Choices]] -> [Int]
counts = filter (/=1) . map length . concat

-- | Expandiere eine Zelle mittels expand1, dies rekursiv. Dadurch wird nach jeder Expansion nur
-- weiter expandiert was noch "legal" ist! Vergleiche mit 'expand', das auch illegale Kandidaten
-- generiert.

expandBetter :: Matrix Choices -> [Grid]
expandBetter = concatMap expandBetter . expand1

-- | Gibt es noch Expaniermoeglichkeiten?

complete :: [[[a]]] -> Bool
complete = all (all singleton)

-- | Ist dieser Kandidat ok?

safe m = all ok (rows m) && all ok (cols m) && all ok (boxs m)
  where ok row = nodups [ d | [d] <- row ]

-- | Suchfunktion, da expandBetter zu "eager" ist, brauchen wir zwischendurch Testmoeglichkeiten.

search :: Matrix Choices -> [Matrix Digit]
search m
  | not (safe m) = []
  | complete m' = [map (map head) m']
  | otherwise = concatMap search (expand1 m')
  where m' = prune m

-- | Und wir suchen ...

solveO :: Grid -> [Grid]
solveO = search . choices

