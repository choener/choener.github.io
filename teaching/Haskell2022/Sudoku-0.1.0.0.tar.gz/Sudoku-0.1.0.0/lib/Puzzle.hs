{-# LANGUAGE TypeFamilies #-}

-- | Die Klasse generischer Puzzles, im Original aus *Pearls of Functional Algorithm Design*, Bird.
-- Kapitel 20, "The Countdown Problem"

module Puzzle where



-- | Puzzles die durch 'moves' geloest werden koennen und sich durch States zwischen den Moves
-- auszeichnen.

class Puzzle p where
  -- | Der aktuelle Zustand des Puzzles
  data PState p :: *
  -- | Ein Schritt zwischen zwei Zustaenden
  data Move p :: *
  -- | Alle moves von einem State aus
  moves :: PState p -> [Move p]
  -- | State nach State mittels Move
  move :: PState p -> Move p -> PState p
  -- | Ist das Problem geloest?
  solved :: PState p -> Bool

