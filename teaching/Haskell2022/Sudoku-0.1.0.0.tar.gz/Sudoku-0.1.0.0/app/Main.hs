module Main where

import Sudoku
import System.Environment (getArgs)

main :: IO ()
main = do
  [solver, fpath] <- getArgs
  s <- fromFile fpath
  putStrLn "Input Sudoku:"
  showSudoku s
  putStrLn "\n"
  let rs = case solver of
            "t" -> solveT s
            "p" -> solveP s
            "o" -> solveO s
  case rs of
    [] -> putStrLn "no solution"
    (r:_) -> do
      putStrLn "first solution"
      showSudoku r
