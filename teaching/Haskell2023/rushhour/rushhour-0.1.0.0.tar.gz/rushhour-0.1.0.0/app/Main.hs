module Main where

import qualified Data.List as L

-- | Art des Autos

data Art = V | H | Ziel
  deriving (Show, Eq, Ord)

data Mauer = Mauer Int Int
  deriving (Show,Eq,Ord)

data Fahrzeug = Fahrzeug
  { zeile, spalte :: Int -- ^ Kopf des Fahrzeuges
  , laenge :: Int
  , art :: Art
  , statRestr :: (Int,Int)  -- ^ maximal [1,N], achtung: Mauern
  }
  deriving (Show,Eq,Ord)

data Spielzustand = Spielzustand
  { fahrzeuge :: [Fahrzeug]
  , mauern :: [Mauer] -- ^ nur zum plotten noetig!
  }

type N = Int
type Spalte = [Int]

spaltenRestriktionen :: N -> [Fahrzeug] -> [Spalte]
spaltenRestriktionen n fs = map go [0..n-1]
  where
    go k = L.foldl' L.union [] [ gen k f | f <- fs ]
    gen k f =
      case art f of
        V -> if spalte f == k then [zeile f .. zeile f + laenge f - 1] else []
        H -> ([zeile f | spalte f <= k && spalte f + laenge f - 1 >= k])
        Ziel -> gen k (f {art = H})

-- TODO dynamische Restriktionen
-- TODO was ist ein move

main :: IO ()
main = putStrLn "Hello, Haskell!"


-- TODO expand generic puzzles to generic puzzles with weighted moves: moves :: [ (Move, Maybe
-- Score) ]

